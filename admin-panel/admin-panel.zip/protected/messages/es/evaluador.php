<?php
return array(
		'showScore'=>'Show Score',
		'back'=>'Back',
		'showNotes'=>'Show Notes',
		'fullScreen'=>'Full Screen',
		'beginPhotoReview'=>'Begin Photo Review',
		'category'=>'Category',
		'nocategory'=>'No category',
		'honorableMention'=>'Honorable Mention',
		'messageSuccess'=>'Update successfull',
		'messageError'=>'There was an error please try again later',
		'categorySuggestions'=>'Category suggestions',
		'noSuggestions'=>'No suggestions',
		'empty'=>'Empty',
		'goToFeedbacks'=>'Go to Feedbacks',
		'goToDescription'=>'Go to Description'
);
