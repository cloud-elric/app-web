<?php
return array(
	'titleTotal'=>'Total',
	'inputSearch'=>'Name, last name or email',
	'btnSearch'=>'Search',
	'exportarRadioCsv'=>'Csv',
	'exportarRadioCsvFotos'=>'Csv + photos',
	'exportarRadioCsvRaw'=>'Csv + Raw',
	'exportarBtn'=>'Export',
	'tabAll'=>'All',
	'tabConFeedback'=>'With Feedback',
	'tabSinFeedback'=>'Without Feedback',
	'tabConMenciones'=>'With Mentions',
	'selectSelecciona'=>'Select',
	'checkBoxAll'=>'Select All',
	'numFotos'=>'photos',
	'of'=>'of'	
);