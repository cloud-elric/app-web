<?php
return array(
		'noFoto'=>'No picture provided',
		'ver'=>'Quick View',	
);