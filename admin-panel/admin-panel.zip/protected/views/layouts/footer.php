
<!-- footer -->
<footer class="footer-fixed">
	<a href="<?=Yii::app()->params['powered']['urlPoweredAuthor']?>" target="_blank"><?=Yii::t('general', 'textFooter')?></a>
</footer>
<!-- end / footer -->