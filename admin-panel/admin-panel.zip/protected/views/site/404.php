<!-- .error-404 -->
<div class="error-404">
	<div class="mask-error"></div>
	<div class="error-cont flex-login">

		<div class="error-cont-datos">
			<h3>404</h3>
			<p>Parece que esta página no existe</p>

			<?php echo CHtml::link("Regresar al sitio principal", array("usrUsuarios/concurso"), array("class"=>"error-cont-a")); ?>
		</div>

	</div>
</div>
<!-- end / .error-404 -->