<!-- .error-404 -->
<div class="error-404">
	<div class="mask-error"></div>
	<div class="error-cont flex-login">

		<div class="error-cont-datos">
			<h3>En construcción</h3>
			<p>Aquí estara el profile del usuario</p>

			<?php echo CHtml::link("Regresar al sitio principal", array("usrUsuarios/concurso"), array("class"=>"error-cont-a")); ?>
		</div>

	</div>
</div>
<!-- end / .error-404 -->