<?php
class Configuracion {
	
	const TIE_BREAKER = true;
	//const DOMINIO_SITIO ='http://dgomphoto.azurewebsites.net';
	//const DOMINIO_SITIO ='http://notei.com.mx';
	//const DOMINIO_SITIO ='https://globaljudging.com';
	const DOMINIO_SITIO ='http://localhost';
	
}