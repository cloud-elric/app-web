<?php
return array(
		'textFooter'=>'Powered by 2 Geeks one Monkey',
		'bienvenido'=>'Welcome',
		'consulta'=>'View contest rules',
		'derechos'=>'GlobalJudging',
		'saludo'=>'Hello'
);