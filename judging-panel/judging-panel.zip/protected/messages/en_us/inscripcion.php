<?php
return array(
		'header'=>'Please select an entry type',
		'note'=>'',
		'terminos'=>'I accept terms and conditions',
		'headerTerminos'=>'Terms and conditions',
		'acepto'=>'I accept terms and conditions',
		'warningProducto'=>'Please select an entry type',
		'submit'=>'Checkout'
);