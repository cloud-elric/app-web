<?php
return array(
		'user'=>'El usuario ',
		'mail'=>' con el email ',
		'instruccionProblema'=>' presenta un problema del tipo ',
		'instruccionProblemaOcaciono'=>' y lo ocurrido fue ',
);