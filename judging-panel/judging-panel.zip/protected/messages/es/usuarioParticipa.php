<?php
return array(
		'noFoto'=>'Sin foto',
		'ver'=>'Ver',
		
);