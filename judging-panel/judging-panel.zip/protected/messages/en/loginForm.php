<?php
return array(
		'username'=>'Correo electrónico',
		'password'=>'Contraseña',
		'rememberMe'=>'Recordarme la siguiente vez',
);