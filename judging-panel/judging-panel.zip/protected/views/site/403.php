<!-- .error-403 -->
<div class="error-403">
	<div class="mask-error"></div>
	<div class="error-cont flex-error">

		<div class="error-cont-datos">
			<h3>403</h3>
			<p>Parece que esta página no existe</p>

			<?php echo CHtml::link("Regresar al sitio principal", array("site/index"), array("class"=>"error-cont-a")); ?>
		</div>

	</div>
</div>
<!-- end / .error-403 -->