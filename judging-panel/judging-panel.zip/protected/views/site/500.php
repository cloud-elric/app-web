<!-- .error-500 -->
<div class="error-500">
	<div class="mask-error"></div>
	<div class="error-cont">

		<div class="error-cont-datos">
			<h3>500</h3>

			<p class="error-cont-datos-500-p">Esta vex el eror esta de nuestro lado, pero ya <span>estamos trabajando en arreglarlo.</span></p>

			<p class="error-cont-datos-500-p">Mientras puedes salir a tomar mas fotos o ver<span>fotos de nuestros concursos pasados.</span></p>

			<?php echo CHtml::link("Ver concursos anteriores", array("usrUsurios/concurso"), array("class"=>"btn-green")); ?>
		</div>

	</div>
</div>
<!-- end / .error-500 -->