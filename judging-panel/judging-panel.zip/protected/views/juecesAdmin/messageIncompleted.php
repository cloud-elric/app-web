<?php
echo Yii::t('finalists', 'incompleted');